declare module 'react-json-editor-ajrm';
