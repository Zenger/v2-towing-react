const Impound = (props: any) => { }
export default Impound;
